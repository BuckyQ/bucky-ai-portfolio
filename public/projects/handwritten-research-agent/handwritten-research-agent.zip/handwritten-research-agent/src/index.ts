import { getDecision } from "./agent/decision.js";
import { resolveDecision } from "./agent/control.js";
import { executeAction } from "./agent/executor.js";
import {type AgentState} from './types/agent.js';
import { generateAnswer } from "./actions/generate.js";

const state: AgentState = {
  query:
  "Research OpenAI Agents SDK features, pricing, and production limitations",

  plan: [
    {
      description: "Search ONLY the core features of OpenAI Agents SDK. Do not research pricing or production limitations.",
      type: "WEB_SEARCH",
    },
    {
      description: "Analyze only the SDK features found so far.",
      type: "ANALYZE",
    },
  ],

  evidence: [],
  analyses: [],
  attempts: 0,
  currentStep: 0,
};

const MAX_ATTEMPTS = 5;

while (state.attempts < MAX_ATTEMPTS &&
  !state.answer) {
  console.log(`\n--- Round ${state.attempts + 1} ---`);

  const decision = await getDecision(state);

  if (!decision) {
    console.warn("Decision unavailable. Exiting control loop.");
    break;
  }
  const action = resolveDecision(decision);

  console.log("Decision:", decision);
  console.log("Resolved Action:", action);

  await executeAction(action, state);

  console.log("Current Step:", state.currentStep);

  console.log(
    "Evidence:",
    state.evidence.map((e, i) => ({
      index: i,
      content: e.content.slice(0, 300),
    }))
  );

  console.log("Analyses:", state.analyses);

  state.attempts += 1;

  if (action === "GENERATE") {
    break;
  }
}

if (!state.answer) {
  console.log("No final answer generated. Using best-effort fallback.");

  state.answer = await generateAnswer(state);
}

console.log("Final Answer:");
console.log(state.answer);
