import { formatEvidence, formatAnalyses } from "../utils/context.js";
import OpenAI from "openai";
import "dotenv/config";
import type { AgentState } from "../types/agent.js";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function generateAnswer(
  state: AgentState
): Promise<string> {

  // 1. 把 evidence 整理成 context
    const context = formatEvidence(state.evidence, 1);
    const analysisContext = formatAnalyses(state.analyses);

  // 2. client.responses.create(...)
    const responses = await client.responses.create({
        model: 'gpt-3.5-turbo',
        input: `
        User query: ${state.query}

        Research evidence: ${context}

        Analysis: ${analysisContext}

        Answer the user's query using the research evidence and analysis.
        `,
    })

    return responses.output_text
}
