import type { AgentState } from "../types/agent.js";
import { createSearchQuery } from "./createSearchQuery.js";
import { webSearch } from "../tools/webSearch.js";

export async function searchMore(state: AgentState) {
  const request = await createSearchQuery(state);

  console.log("Search reason:", request.reason);
  console.log("Search query:", request.query);

  const evidence = await webSearch(request.query);

  state.evidence.push(evidence);

  return state;
}
