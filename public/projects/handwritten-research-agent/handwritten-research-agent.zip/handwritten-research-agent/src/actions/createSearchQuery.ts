import { formatEvidence, formatAnalyses } from "../utils/context.js";
import { SearchQuerySchema } from "../schemas/agent.js";

import type { AgentState, SearchQuery } from "../types/agent.js";

import OpenAI from "openai";
import "dotenv/config";
import { zodTextFormat } from "openai/helpers/zod";
const client = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
})



export async function createSearchQuery(
  state: AgentState
): Promise<SearchQuery> {

    const evidenceContext = formatEvidence(state.evidence);

    const analysisContext = formatAnalyses(state.analyses);



    const response = await client.responses.parse({
        model: 'gpt-3.5-turbo',
        input: [{role: "system", content: `
        You generate targeted search queries for a research agent.

        Use the user's original goal, existing evidence, and analysis
        to identify what information is still missing.

        Generate one targeted search query.
        `}, {
            role: 'user',
            content: `
            Original goal:
            ${state.query}

            Evidence:
            ${evidenceContext}

            Analysis:
            ${analysisContext}
            `
        }],

        text: {
            format: zodTextFormat(SearchQuerySchema, "search_more")
        }
    })

    const parsed = response.output_parsed;
    if (!parsed) {
        throw new Error('Failed to generate a search query.');
    }

    return parsed;
}
