import { formatEvidence } from "../utils/context.js";
import { type AgentState, type Analysis } from "../types/agent.js";

import OpenAI from "openai";
import "dotenv/config";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});



export async function analyze(
  state: AgentState,
  instruction: string,
): Promise<Analysis> {
    const context = formatEvidence(state.evidence);

  // 2. responses.create()
  // query + instruction + evidence
    const response = await client.responses.create({
        model: "gpt-5-nano",
        input: `
        query: ${state.query}

        instruction; ${instruction}

        evidence: ${context}
        `,
    })

    return {
        content: response.output_text,
        basedOn: state.evidence.map((_, index) => index),
    }
}
