import { type Evidence } from "../types/agent.js";

import OpenAI from "openai";
import "dotenv/config";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function webSearch(
  query: string
): Promise<Evidence> {
  try {
   const response = await client.responses.create({
        model: process.env.OPENAI_MODEL ?? "gpt-6-luna",
        tools: [{type: 'web_search'}],

        input: `search the web for information relevant to this research query :
            ${query}

            Prefer primary and official sources
        `,
   })
   
   const content = response.output_text?.trim();

    if (!content) {
      throw new Error("Web search returned an empty response");
    }

    return {
      content,
      source: "web-search",
    };

  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);

    return {
      content: `Web search failed: ${message}`,
      source: "web-search-error",
    };
  }
}
